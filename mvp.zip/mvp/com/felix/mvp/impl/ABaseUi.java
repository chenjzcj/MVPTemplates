package com.felix.mvp.impl;

import android.content.Context;

import com.felix.mvp.view.Ui;


/**
 * Created by Felix on 2017/3/10.
 * <p>
 * 返回Context对象的Ui封装
 */
public interface ABaseUi extends Ui {
    Context getContext();
}
