package com.felix.mvp.impl;

import com.felix.mvp.presenter.BasePresenter;
import com.felix.mvp.utils.LifeCycleUtil;

/**
 * Created by Felix on 2016/11/21.
 * <p>
 * 封装相同函数实现的Presenter
 */
public abstract class ABasePresenter<U extends ABaseUi> extends BasePresenter<U> {

    protected boolean isUiDestroy() {
        return LifeCycleUtil.isUiDestroyed(getUi());
    }

}
