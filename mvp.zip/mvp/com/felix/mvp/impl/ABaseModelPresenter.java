package com.felix.mvp.impl;

import com.felix.mvp.model.Model;
import com.felix.mvp.presenter.BaseModelPresenter;
import com.felix.mvp.utils.LifeCycleUtil;

/**
 * Created by Felix on 2016/11/21.
 * <p>
 * 封装相同函数实现的Presenter
 */
public abstract class ABaseModelPresenter<U extends ABaseUi, M extends Model> extends BaseModelPresenter<U, M> {

    protected boolean isUiDestroy() {
        return LifeCycleUtil.isUiDestroyed(getUi());
    }

}
