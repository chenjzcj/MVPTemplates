package com.felix.mvp.view.support;

import android.os.Bundle;

import com.felix.mvp.presenter.IPresenter;
import com.felix.mvp.view.Ui;
import com.felix.mvp.view.UiCreator;
import com.felix.mvp.view.UiCreatorAdapter;
import com.felix.mvp.view.UiFactory;


/**
 * Created by Felix on 2015/3/26.
 */
public abstract class BaseFragmentActivity<P extends IPresenter, U extends Ui> extends android.support.v4.app.FragmentActivity implements UiFactory<P, U> {

    protected UiCreator<U> mUiAdapter;

    private P mPresenter;

    @Override
    public P getPresenter() {
        return mPresenter;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPresenter = createPresenter();
        mUiAdapter = new UiCreatorAdapter<>(mPresenter, getUiImplement());
        mUiAdapter.bindPresenterModel();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        mUiAdapter.unbindPresenter();
    }
}
